from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm


# fields=[__all__] - > para usar todos os campos

class LoginForm(forms.Form):
    class Meta:
        model=User
        fields=[
            'fist_name',
            'last_name',
            'username',
            'password',
            'email',
        ]


class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}))