from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .forms import LoginForm ,CustomLoginForm
from django.contrib import messages
from django.contrib.auth.views import LoginView



class CustomLoginView(LoginView):
    template_name = 'login/login.html'  # O nome do modelo que será usado para renderizar a tela de login
    authentication_form = CustomLoginForm  # Use o formulário personalizado