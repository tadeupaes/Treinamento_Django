from django.shortcuts import render

# Create your views here.
def indexg(request):
    html='core/index2.html'
    contexto={}
    return render(request,html,contexto)