from django.urls import path
from . import views

urlpatterns = [
   path('',views.dashcad ,name='dashcad'),
   path('listaempresa',views.listaempresa,name='listaempresa'),
   path('listaempresa/novo/', views.criar_empresa, name='cadastro_empresa'),
   path('listaempresa/<int:pk>/edit',views.empresa_edit, name='empresa_edit'),
   path('desenvolvedores/', views.lista_desenvolvedores, name='lista_desenvolvedores'),
   path('desenvolvedores/novo/', views.criar_desenvolvedor, name='criar_desenvolvedor'),
   path('linguagens/', views.lista_linguagens, name='lista_linguagens'),
   path('linguagens/novo/', views.criar_linguagem, name='criar_linguagem'),
   path('linguagens/<int:id>/edit/', views.linguagem_edit, name='linguagem_edit'),
   path('linguagens/<int:id>/delete/', views.linguagem_delete, name='linguagem_delete'),
   path('projetos/', views.lista_projetos, name='lista_projetos'),
   path('projetos/novo/', views.criar_projeto, name='criar_projeto'),
]

