from django.db import models

# Create your models here.
#Camada - Cadastrar as Empresas 


class EmpresaModel(models.Model):
    nome =models.CharField(max_length=200)
    

class M_Empresa(models.Model):
    nome =  models.CharField(max_length=100)

    def __str__(self):
        return self.nome
    
# Camada - Linguagem
class M_linguagem(models.Model):
    nome =models.CharField(max_length=150)

    def __str__(self):
        return self.nome

# Camada - Desenvolvedores

class M_Desenvolvedor(models.Model):
    nome =models.CharField(max_length=100)
    empresa = models.ForeignKey(M_Empresa , on_delete=models.CASCADE)
    linguagem = models.ManyToManyField('M_linguagem')

    def __str__(self):
        return self.nome
    
    #Camada Projeto

class M_Projeto(models.Model):
    titulo=models.CharField(max_length=200)
    empresa = models.ForeignKey(M_Empresa, on_delete=models.CASCADE)
    desenvolvedores =models.ManyToManyField('M_Desenvolvedor')

    def __str__(self):
        return self.titulo
        
            
              