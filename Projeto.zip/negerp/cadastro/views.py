from django.shortcuts import render ,redirect,get_object_or_404
from .models import M_Empresa , M_linguagem ,M_Desenvolvedor, M_Projeto
from .forms import F_Empresa, F_linguagem  , DesenvolvedorForm , ProjetoForm

# Create your views here.
# VIEW DO DASHBOARD
def dashcad(request):
    html=''
    contexto={}
    return render(request,html,contexto)

# VIEW DO EMPRESAS
def listaempresa(request):
    dados = M_Empresa.objects.all()
    html='cadastro/Empresa/listaempresa.html'
    contexto={'empresas':dados}
    return render(request,html,contexto)

def criar_empresa(request):
    if request.method == 'POST':
        form = F_Empresa(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listaempresa')
    else:
        form = F_Empresa()
    return render(request, 'cadastro/Empresa/cadempresa.html', {'form': form})


def empresa_edit(request,pk):
    empresa = get_object_or_404(M_Empresa, pk=pk)
    if request.method =='POST':
        form = F_Empresa(request.POST, instance=empresa)
        if form.is_valid():
            form.save()
            return redirect('listaempresa')
    else:
        form=F_Empresa(instance=empresa)
    return render(request,'cadastro/Empresa/empresa_form.html',{'form':form})

# VIEW DO DESENVOLVEDORES






# VIEW DO LINGUAGEM
def criar_linguagem(request):
    if request.method == 'POST':
        form = F_linguagem(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_linguagens')
    else:
        form = F_linguagem()
    return render(request, 'cadastro/Linguagem/criar_linguagem.html', {'form': form})

def lista_linguagens(request):
    linguagens = M_linguagem.objects.all()
    return render(request, 'cadastro/Linguagem/lista_linguagens.html', {'linguagens': linguagens})

def linguagem_edit(request, id):
    linguagem = get_object_or_404(M_linguagem, id=id)
    if request.method == 'POST':
        form = F_linguagem(request.POST, instance=linguagem)
        if form.is_valid():
            form.save()
            return redirect('lista_linguagens')
    else:
        form = F_linguagem(instance=linguagem)
    return render(request, 'cadastro/linguagem/linguagem_form.html', {'form': form})

def linguagem_delete(request, id):
    linguagem = get_object_or_404(M_linguagem, id=id)
    if request.method == 'POST':
        linguagem.delete()
        return redirect('lista_linguagens')
    return render(request, 'cadastro/Linguagem/linguagem_confirm_delete.html', {'empresa': empresa})


# VIEW DO PROJETOS
def criar_projeto(request):
    if request.method == 'POST':
        form = ProjetoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_projetos')
    else:
        form = ProjetoForm()
    return render(request, 'cadastro/Projeto/criar_projeto.html', {'form': form})

def lista_projetos(request):
    projetos = M_Projeto.objects.all()
    return render(request, 'cadastro/Projeto/lista_projetos.html', {'projetos': projetos})


# VIEW DO DESENVOLVEDORES
def criar_desenvolvedor(request):
    if request.method == 'POST':
        form = DesenvolvedorForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_desenvolvedores')
    else:
        form = DesenvolvedorForm()
    return render(request, 'cadastro/Desenvolvedor/criar_desenvolvedor.html', {'form': form})

def lista_desenvolvedores(request):
    desenvolvedores = M_Desenvolvedor.objects.all()
    return render(request, 'cadastro/Desenvolvedor/lista_desenvolvedores.html', {'desenvolvedores': desenvolvedores})
