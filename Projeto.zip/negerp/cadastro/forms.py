from django import forms
from .models import M_Empresa , M_linguagem ,M_Desenvolvedor , M_Projeto

#F_Empresa  -> EmpresaForms
class F_Empresa(forms.ModelForm):
    class Meta:
        model = M_Empresa  
        fields = ['nome']
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nome da Empresa'}),
        }


class F_linguagem(forms.ModelForm):
    class Meta:
        model = M_linguagem
        fields = ['nome']

        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nome da linguagem'}),
        }


class DesenvolvedorForm(forms.ModelForm):
    class Meta:
        model = M_Desenvolvedor
        fields = ['nome', 'empresa', 'linguagem']
        widgets = {
            'linguagem': forms.CheckboxSelectMultiple(),
        }

class ProjetoForm(forms.ModelForm):
    class Meta:
        model = M_Projeto
        fields = ['titulo', 'empresa', 'desenvolvedores']
        widgets = {
            'desenvolvedores': forms.CheckboxSelectMultiple(),
        }
